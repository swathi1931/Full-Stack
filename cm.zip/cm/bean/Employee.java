package com.cg.eis.bean;


public class Employee{

private int empid;
private String empName;
private int empSalary;
private String empDesignation;
private String empInsuranceScheme;
public int getEmpid() {
    return empid;
}
public void setEmpid(int empid) {
    this.empid = empid;
}
public String getEmpName() {
    return empName;
}
public void setEmpName(String empName) {
    this.empName = empName;
}
public int getEmpSalary() {
    return empSalary;
}
public void setEmpSalary(int empSalary) {
    this.empSalary = empSalary;
}
public String getEmpDesignation() {
    return empDesignation;
}
public void setEmpDesignation(String empDesignation) {
    this.empDesignation = empDesignation;
}
public String getEmpInsuranceScheme() {
    return empInsuranceScheme;
}
public void setEmpInsuranceScheme(String empInsuranceScheme) {
    this.empInsuranceScheme = empInsuranceScheme;
}
public Employee(int empid, String empName, int empSalary, String empDesignation, String empInsuranceScheme) {
    super();
    this.empid = empid;
    this.empName = empName;
    this.empSalary = empSalary;
    this.empDesignation = empDesignation;
    this.empInsuranceScheme = empInsuranceScheme;
}
public Employee() {
	// TODO Auto-generated constructor stub
}
   
}