package com.cg.eis.service;

public interface EmployeeService 
{
    public void getEmployeeDetails(int eid,String ename,int sal);
}